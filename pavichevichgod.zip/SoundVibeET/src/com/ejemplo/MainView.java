package com.ejemplo;

import javax.swing.*;
import java.awt.*;

public class MainView extends JFrame {
    public MainView() {
        // Configuración básica de la ventana
        setTitle("SoundVibe - Vista Principal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel principal
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.BLACK);
        mainPanel.setLayout(new BorderLayout());

        // Panel central (contenido principal)
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.BLACK);

        // Panel superior con el logo
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(Color.BLACK);
        JLabel logoLabel = new JLabel(new ImageIcon("src/assets/gogo.png"));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        logoPanel.add(logoLabel);

        // Espacio adicional para mover el logo hacia abajo
        JPanel logoSpacerPanel = new JPanel();
        logoSpacerPanel.setBackground(Color.BLACK);
        logoSpacerPanel.setPreferredSize(new Dimension(0, 50)); // Espacio de 50 píxeles

        // Texto de bienvenida
        JLabel welcomeLabel = new JLabel("¡Bienvenido a SoundVibe!");
        welcomeLabel.setForeground(new Color(255, 20, 147)); // Fucsia
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 22));

        // Alineación centrada de texto dentro de un JPanel
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(Color.BLACK);
        welcomePanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Centra el contenido
        welcomePanel.add(welcomeLabel);

        // Panel con botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // Centra los botones con espacio entre ellos

        JButton offlineButton = createStyledButton("Reproducción Offline");
        JButton onlineButton = createStyledButton("Reproducción Online");

        // Acciones de los botones
        offlineButton.addActionListener(e -> {
            dispose(); // Cerrar la vista principal
            new MusicPlayerGUI(); // Abrir MusicPlayerGUI
        });

        onlineButton.addActionListener(e -> {
            dispose(); // Cierra la ventana actual
            JFrame login = new LoginScreen();
            login.setVisible(true); // Asegúrate de mostrar la ventana
        });

        // Añadir botones al panel
        buttonPanel.add(offlineButton);
        buttonPanel.add(onlineButton);

        // Añadir logo y texto al centro
        JPanel contentPanel = new JPanel();
        contentPanel.setBackground(Color.BLACK);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.add(logoSpacerPanel); // Espacio antes del logo
        contentPanel.add(logoPanel); // Logo en la parte superior
        contentPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio entre logo y texto
        contentPanel.add(welcomePanel); // Ahora el texto está centrado
        contentPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio entre texto y botones
        contentPanel.add(buttonPanel); // Botones debajo del texto

        // Centrar el contenido
        centerPanel.add(contentPanel, BorderLayout.CENTER);

        // Panel lateral izquierdo
        JPanel leftPanel = createSidePanel(new String[]{"Explorar", "Mis Listas", "Artistas", "Álbumes", "Configuración"});
        centerPanel.add(leftPanel, BorderLayout.WEST);

        // Panel lateral derecho (Top semanal)
        JPanel rightPanel = createTopWeeklyPanel();
        centerPanel.add(rightPanel, BorderLayout.EAST);

        // Añadir al panel principal
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        add(mainPanel);
    }

    // Método para crear botones estilizados
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 20, 147)); // Fucsia
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    // Método para crear un panel lateral izquierdo
    private JPanel createSidePanel(String[] options) {
        JPanel sidePanel = new JPanel();
        sidePanel.setLayout(new BoxLayout(sidePanel, BoxLayout.Y_AXIS));
        sidePanel.setBackground(new Color(30, 30, 30));
        sidePanel.setPreferredSize(new Dimension(150, 0));

        for (String option : options) {
            JLabel label = new JLabel(option);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("SansSerif", Font.PLAIN, 14));
            label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            label.setCursor(new Cursor(Cursor.HAND_CURSOR));
            label.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent e) {
                    label.setForeground(new Color(255, 20, 147));
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent e) {
                    label.setForeground(Color.WHITE);
                }
            });
            sidePanel.add(label);
        }
        return sidePanel;
    }

    // Método para crear un panel lateral derecho con el Top Semanal
    private JPanel createTopWeeklyPanel() {
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(new Color(30, 30, 30));
        topPanel.setPreferredSize(new Dimension(200, 0));
        topPanel.setBorder(BorderFactory.createTitledBorder(null, "Top Semanal", 0, 0, new Font("SansSerif", Font.BOLD, 12), Color.WHITE));

        // Canciones del Top Semanal
        String[] topSongs = {
            "1. Quédate - Quevedo, Bizarrap",
            "2. Los del Espacio - Duki, María Becerra",
            "3. Ojitos Lindos - Bad Bunny, Bomba Estéreo",
            "4. Flowers - Miley Cyrus",
            "5. Ella Baila Sola - Eslabón Armado, Peso Pluma"
        };

        for (String song : topSongs) {
            JLabel songLabel = new JLabel(song);
            songLabel.setForeground(Color.WHITE);
            songLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
            songLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            topPanel.add(songLabel);
        }
        return topPanel;
    }
}
