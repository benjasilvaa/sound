package com.ejemplo;

import javax.swing.*;
import java.awt.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterScreen extends JFrame {
	public boolean registerUser(String nombre, String correo, String contraseña) {
	    try (Connection conn = DatabaseConnection.getConnection()) {
	        if (conn != null) {
	            String sql = "INSERT INTO usuarios (nombre, correo, contraseña) VALUES (?, ?, ?)";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setString(1, nombre);
	            statement.setString(2, correo);
	            statement.setString(3, contraseña);

	            int rowsInserted = statement.executeUpdate();
	            return rowsInserted > 0; // Devuelve true si se insertó al menos un registro
	        }
	    } catch (SQLException e) {
	        System.out.println("Error al registrar el usuario: " + e.getMessage());
	    }
	    return false; // Devuelve false en caso de error
	}





    // Llama a este método cuando se presione el botón de registro:
    // registerUser(userField.getText(), emailField.getText(), new String(passField.getPassword()));
    public RegisterScreen() {
        setTitle("Registro de Usuario");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel de fondo negro
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.BLACK);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBackground(Color.BLACK);

        JLabel userLabel = new JLabel("Usuario:");
        JTextField userField = new JTextField();
        JLabel emailLabel = new JLabel("Correo:");
        JTextField emailField = new JTextField();
        JLabel passLabel = new JLabel("Contraseña:");
        JPasswordField passField = new JPasswordField();
        JLabel confirmPassLabel = new JLabel("Confirmar Contraseña:");
        JPasswordField confirmPassField = new JPasswordField();

        // Estilo de etiquetas y campos en blanco
        userLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        emailLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        confirmPassLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        userLabel.setForeground(Color.WHITE);
        emailLabel.setForeground(Color.WHITE);
        passLabel.setForeground(Color.WHITE);
        confirmPassLabel.setForeground(Color.WHITE);
        userField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        emailField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        passField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        confirmPassField.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JButton registerButton = createStyledButton("Registrarse");

        // Añadir componentes al panel
        panel.add(userLabel);
        panel.add(userField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(confirmPassLabel);
        panel.add(confirmPassField);
        panel.add(new JLabel()); // Espacio vacío
        panel.add(registerButton);

        mainPanel.add(panel);
        add(mainPanel);

        // Acción del botón de registro
        registerButton.addActionListener(e -> {
            if (userField.getText().isEmpty() || emailField.getText().isEmpty() ||
                passField.getPassword().length == 0 || confirmPassField.getPassword().length == 0) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!String.valueOf(passField.getPassword()).equals(String.valueOf(confirmPassField.getPassword()))) {
                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Llama al método registerUser y verifica si fue exitoso
                if (registerUser(userField.getText(), emailField.getText(), new String(passField.getPassword()))) {
                    JOptionPane.showMessageDialog(null, "Registro exitoso");
                    dispose(); // Cierra la pantalla de registro
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


    }

    // Método para crear botones fucsia estilizados
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 20, 147)); // Fucsia
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}


