package com.ejemplo;

import javax.swing.*;

import javax.swing.Timer;
import javafx.embed.swing.JFXPanel; // Inicializa JavaFX en una aplicación Swing
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class YouTubePlayerGUI extends JFrame {
    private static final Color FRAME_COLOR = Color.BLACK;
    private static final Color TEXT_COLOR = Color.WHITE;
    
    private JSlider progressBar;
    private JLabel timeLabel;
    private Timer progressTimer;

    private JTextField searchField;
    private JButton playPauseButton, previousButton, nextButton;
    private JLabel coverImageLabel;
    private JLabel titleLabel;
    private JLabel artistLabel;
    private AudioPlayer audioPlayer;
    private JButton playlistButton;
    private JButton createPlaylistButton;
    private JButton loadPlaylistButton;
    

    public YouTubePlayerGUI() {
    	new JFXPanel();  // Necesario para que JavaFX funcione en una aplicación Swing
        setTitle("Reproductor de YouTube - Audio");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(FRAME_COLOR);
       
        JPanel playbackBtns = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5)); // Layout ajustado con espaciado
        playbackBtns.setBounds(0, 450, getWidth(), 80);
        playbackBtns.setBackground(null);
        
     // Dentro del constructor (donde configuras la interfaz)
        progressBar = new JSlider(0, 100, 0); // Rango inicial (min: 0, max: 100, valor inicial: 0)
        progressBar.setBounds(50, 420, 300, 20); // Ajusta la posición y tamaño
        progressBar.setEnabled(false); // Deshabilitado para no permitir manipulación manual
        add(progressBar);

        timeLabel = new JLabel("00:00 / 00:00", SwingConstants.CENTER); // Etiqueta para tiempo
        timeLabel.setBounds(150, 450, 100, 20); // Ajusta la posición
        timeLabel.setForeground(TEXT_COLOR); // Color del texto
        add(timeLabel);

        // Configura el Timer para actualizar la barra de progreso
        progressTimer = new Timer(1000, e -> updateProgress());
        
     // Dentro del constructor (donde configuras la interfaz)
        playlistButton = new JButton("Playlists");
        playlistButton.setBackground(Color.LIGHT_GRAY);
        playlistButton.setBorderPainted(false);
        playlistButton.setBounds(150, 50, 100, 30); // Mueve el botón a la parte superior
        playlistButton.addActionListener(e -> togglePlaylistButtons());
        add(playlistButton);

        // Botones secundarios (crear y cargar playlist) justo debajo del botón "Playlists"
        createPlaylistButton = new JButton("Crear Playlist");
        createPlaylistButton.setBounds(150, 90, 120, 30); // Posicionado debajo de "Playlists"
        createPlaylistButton.setVisible(false);
        createPlaylistButton.addActionListener(e -> createPlaylist());
        add(createPlaylistButton);

        loadPlaylistButton = new JButton("Cargar Playlist");
        loadPlaylistButton.setBounds(150, 130, 120, 30); // Posicionado debajo de "Crear Playlist"
        loadPlaylistButton.setVisible(false);
        loadPlaylistButton.addActionListener(e -> loadPlaylist());
        add(loadPlaylistButton);

        // Barra de búsqueda
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        searchPanel.setBounds(0, 0, getWidth(), 40);
        searchPanel.setBackground(FRAME_COLOR);

        JLabel searchLabel = new JLabel("Buscar:");
        searchLabel.setForeground(TEXT_COLOR);
        searchField = new JTextField(15);
        JButton searchButton = new JButton("Buscar");
        searchButton.setBackground(Color.LIGHT_GRAY);
        searchButton.addActionListener(e -> searchAndPlay(searchField.getText()));

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        add(searchPanel);

        // Portada, título y artista
        coverImageLabel = new JLabel();
        coverImageLabel.setBounds(50, 60, 300, 300);
        add(coverImageLabel);

        titleLabel = new JLabel("", SwingConstants.CENTER);
        titleLabel.setBounds(0, 380, getWidth(), 30);
        titleLabel.setForeground(TEXT_COLOR);
        add(titleLabel);

        artistLabel = new JLabel("", SwingConstants.CENTER);
        artistLabel.setBounds(0, 410, getWidth(), 30);
        artistLabel.setForeground(TEXT_COLOR);
        add(artistLabel);

     

        // Botones de reproducción
        previousButton = new JButton(loadImage("src/assets/previous.png")); // Imagen de anterior
        previousButton.setBorderPainted(false);
        previousButton.setBackground(null);
        previousButton.addActionListener(new PreviousListener());
        playbackBtns.add(previousButton);

        playPauseButton = new JButton(loadImage("src/assets/play.png")); // Imagen de play
        playPauseButton.setBorderPainted(false);
        playPauseButton.setBackground(null);
        playPauseButton.addActionListener(new PlayPauseListener());
        playbackBtns.add(playPauseButton);

        nextButton = new JButton(loadImage("src/assets/next.png")); // Imagen de siguiente
        nextButton.setBorderPainted(false);
        nextButton.setBackground(null);
        nextButton.addActionListener(new NextListener());
        playbackBtns.add(nextButton);

        add(playbackBtns);
        setVisible(true);
    }
    
    private void updateProgress() {
        if (audioPlayer != null && audioPlayer.isPlaying()) {
            long currentTime = audioPlayer.getCurrentPosition();
            long totalDuration = audioPlayer.getDuration();

            // Evitar errores de división por cero
            if (totalDuration > 0) {
                // Actualizar el slider y la etiqueta de tiempo
                int progress = (int) ((currentTime * 100) / totalDuration);
                progressBar.setValue(progress);
                timeLabel.setText(formatTime(currentTime) + " / " + formatTime(totalDuration));
            }
        } else {
            progressTimer.stop(); // Detener el Timer si el audio se ha detenido
        }
    }

 // Formato del tiempo
    private String formatTime(long milliseconds) {
        long totalSeconds = milliseconds / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

 // Método para alternar la visibilidad y ajustar la posición
    private void togglePlaylistButtons() {
        boolean visible = createPlaylistButton.isVisible();
        createPlaylistButton.setVisible(!visible);
        loadPlaylistButton.setVisible(!visible);
    }


 // Método para obtener la URL del archivo de audio usando yt-dlp.exe
    public String getAudioUrl(String videoUrl) {
        // Ruta donde está el archivo yt-dlp.exe dentro de la carpeta 'assets' de tu proyecto
        String ytDlpPath = "src/assets/yt-dlp.exe"; // Ajusta la ruta según tu estructura de carpetas

        // Comando que se ejecutará en la terminal
        String command = ytDlpPath + " -f bestaudio --get-url " + videoUrl;

        try {
            // Ejecutar el comando
            ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
            Process process = processBuilder.start();

            // Leer la salida del proceso (que es la URL del audio)
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            String audioUrl = null;
            while ((line = reader.readLine()) != null) {
                audioUrl = line; // La URL del audio está en la salida del proceso
            }

            // Esperar a que el proceso termine
            process.waitFor();

            return audioUrl;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private void createPlaylist() {
        String playlistName = JOptionPane.showInputDialog(this, "Nombre de la nueva playlist:");
        if (playlistName != null && !playlistName.trim().isEmpty()) {
            try {
                DatabaseConnection dbHelper = new DatabaseConnection();
                int userId = 1; // Cambia a obtener dinámicamente el ID del usuario logueado
                dbHelper.insertPlaylist(playlistName, userId);
                JOptionPane.showMessageDialog(this, "Playlist creada con éxito.");
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al crear la playlist.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "El nombre de la playlist no puede estar vacío.");
        }
    }

    private void loadPlaylist() {
        try {
            DatabaseConnection dbHelper = new DatabaseConnection();
            int userId = 1; // Cambia a obtener dinámicamente el ID del usuario logueado
            String[] playlists = dbHelper.getPlaylists(userId); // Obtener nombres de las playlists
            if (playlists.length == 0) {
                JOptionPane.showMessageDialog(this, "No hay playlists disponibles.");
                return;
            }

            String selectedPlaylist = (String) JOptionPane.showInputDialog(
                    this,
                    "Selecciona una playlist:",
                    "Cargar Playlist",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    playlists,
                    playlists[0]
            );

            if (selectedPlaylist != null) {
                dbHelper.loadPlaylist(selectedPlaylist);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar la playlist.");
        }
    }




    private void searchAndPlay(String query) {
        String videoId = YouTubeAPI.searchVideo(query);
        if (videoId != null) {
            String videoUrl = "https://www.youtube.com/watch?v=" + videoId;
            String audioUrl = getAudioUrl(videoUrl);  // Obtener la URL del audio usando yt-dlp

            if (audioUrl != null) {
                String title = YouTubeAPI.getVideoTitle(videoId);
                String artist = YouTubeAPI.getVideoArtist(videoId);
                ImageIcon coverImage = YouTubeAPI.getCoverImage(videoId);

                // Actualizar interfaz gráfica
                titleLabel.setText(title);
                artistLabel.setText(artist);
                coverImageLabel.setIcon(coverImage);

                // Detener cualquier audio que esté en reproducción
                if (audioPlayer != null && audioPlayer.isPlaying()) {
                    audioPlayer.pause();
                    progressTimer.stop(); // Detener el Timer para evitar actualizaciones no deseadas
                }

                // Crear un nuevo reproductor y reproducir el audio
                audioPlayer = new AudioPlayer(audioUrl);
                playPauseButton.setIcon(loadImage("src/assets/pause.png"));
                audioPlayer.play();
                progressBar.setEnabled(true); // Habilitar barra de progreso
                progressTimer.start(); // Iniciar actualización del progreso

                // Asegurarse de que la barra de progreso y el tiempo se actualicen inmediatamente
                updateProgress();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo obtener el audio.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró ningún video.");
        }
    }



    private class PlayPauseListener implements ActionListener {
        private boolean isPlaying = true;

        @Override
        public void actionPerformed(ActionEvent e) {
            if (isPlaying) {
                playPauseButton.setIcon(loadImage("src/assets/play.png"));
                audioPlayer.pause();
            } else {
                playPauseButton.setIcon(loadImage("src/assets/pause.png"));
                audioPlayer.play();
            }
            isPlaying = !isPlaying;
        }
    }

    private class PreviousListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Aquí puedes agregar la lógica para el botón de "Previous"
            System.out.println("Botón de Anterior presionado");
        }
    }

    private class NextListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Aquí puedes agregar la lógica para el botón de "Next"
            System.out.println("Botón de Siguiente presionado");
        }
    }

    private ImageIcon loadImage(String imagePath) {
        try {
            BufferedImage image = ImageIO.read(new File(imagePath));
            return new ImageIcon(image);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
