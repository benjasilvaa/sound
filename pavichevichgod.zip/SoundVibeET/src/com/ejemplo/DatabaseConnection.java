package com.ejemplo;

import java.sql.*;
import java.util.ArrayList;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/soundvibe_db";
    private static final String USER = "root"; // Cambia "root" si tienes otro usuario
    private static final String PASSWORD = ""; // Coloca la contraseña aquí si tienes una

    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return connection;
    }

    public void insertPlaylist(String playlistName, int userId) throws SQLException {
        String procedureCall = "{CALL InsertPlaylist(?, ?)}"; // Llamada al procedimiento almacenado
        try (Connection connection = getConnection();
             CallableStatement stmt = connection.prepareCall(procedureCall)) {
            stmt.setString(1, playlistName); // Establece el primer parámetro
            stmt.setInt(2, userId);          // Establece el segundo parámetro
            stmt.execute();                  // Ejecuta el procedimiento
            System.out.println("Playlist creada con éxito.");
        }
    }


    public String[] getPlaylists(int userId) throws SQLException {
        ArrayList<String> playlists = new ArrayList<>();
        String query = "SELECT nombre_lista FROM playlists WHERE id_usuario = ?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                playlists.add(rs.getString("nombre_lista"));
            }
        }
        return playlists.toArray(new String[0]);
    }

    public void loadPlaylist(String playlistName) throws SQLException {
        String query = """
                SELECT s.titulo, s.artista, s.url_archivo
                FROM playlist_songs ps
                JOIN songs s ON ps.id_cancion = s.id_cancion
                JOIN playlists p ON ps.id_lista = p.id_lista
                WHERE p.nombre_lista = ?""";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, playlistName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Canción: " + rs.getString("titulo") + " - " + rs.getString("artista"));
            }
        }
    }
}
