package com.ejemplo;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class AudioPlayer {
    private MediaPlayer mediaPlayer;

    // Constructor para cargar el audio desde una URL de streaming
    public AudioPlayer(String audioUrl) {
        try {
            Media media = new Media(audioUrl);
            mediaPlayer = new MediaPlayer(media);
        } catch (Exception e) {
            System.out.println("Error al cargar el audio: " + e.getMessage());
        }
    }

    // Método para reproducir el audio
    public void play() {
        if (mediaPlayer != null) {
            mediaPlayer.play();
        }
    }

    // Método para pausar el audio
    public void pause() {
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    // Método para verificar si el audio está siendo reproducido
    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.getStatus() == MediaPlayer.Status.PLAYING;
    }

    // Obtener la posición actual en milisegundos
    public long getCurrentPosition() {
        if (mediaPlayer != null && mediaPlayer.getCurrentTime() != null) {
            return (long) mediaPlayer.getCurrentTime().toMillis();
        }
        return 0; // Retorna 0 si no está listo
    }

    // Obtener la duración total en milisegundos
    public long getDuration() {
        if (mediaPlayer != null && mediaPlayer.getTotalDuration() != null) {
            return (long) mediaPlayer.getTotalDuration().toMillis();
        }
        return 0; // Retorna 0 si no está listo
    }

    // Saltar a un tiempo específico en la reproducción
    public void seek(long positionMillis) {
        if (mediaPlayer != null) {
            mediaPlayer.seek(javafx.util.Duration.millis(positionMillis));
        }
    }
}
