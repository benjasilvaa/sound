package com.ejemplo;

import javax.swing.ImageIcon;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import org.json.JSONArray;
import org.json.JSONObject;

public class YouTubeAPI {
    private static final String API_KEY = "AIzaSyDbvnU57TkQetNhFfdHm0CH5TgYIndan7Q";

    public static String searchVideo(String query) {
        try {
            String apiUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=" 
                            + query.replace(" ", "%20") + "&key=" + API_KEY;

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            JSONObject json = new JSONObject(content.toString());
            JSONArray items = json.getJSONArray("items");

            if (items.length() > 0) {
                JSONObject video = items.getJSONObject(0);
                return video.getJSONObject("id").getString("videoId");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getAudioUrl(String videoId) {
        // Aquí se devuelve el enlace del video como un reproductor de solo audio embebido
        return "https://www.youtube.com/embed/" + videoId + "?autoplay=1";
    }

    public static String getVideoTitle(String videoId) {
        try {
            String apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet&id=" 
                            + videoId + "&key=" + API_KEY;

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            JSONObject json = new JSONObject(content.toString());
            JSONArray items = json.getJSONArray("items");

            if (items.length() > 0) {
                JSONObject snippet = items.getJSONObject(0).getJSONObject("snippet");
                return snippet.getString("title");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getVideoArtist(String videoId) {
        // Generalmente, el canal de YouTube actúa como el "artista"
        try {
            String apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet&id=" 
                            + videoId + "&key=" + API_KEY;

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            JSONObject json = new JSONObject(content.toString());
            JSONArray items = json.getJSONArray("items");

            if (items.length() > 0) {
                JSONObject snippet = items.getJSONObject(0).getJSONObject("snippet");
                return snippet.getString("channelTitle");  // Nombre del canal como "artista"
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ImageIcon getCoverImage(String videoId) {
        try {
            String apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet&id=" 
                            + videoId + "&key=" + API_KEY;

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder content = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            connection.disconnect();

            JSONObject json = new JSONObject(content.toString());
            JSONArray items = json.getJSONArray("items");

            if (items.length() > 0) {
                JSONObject snippet = items.getJSONObject(0).getJSONObject("snippet");
                String imageUrl = snippet.getJSONObject("thumbnails").getJSONObject("high").getString("url");
                
                // Cargar la imagen desde la URL
                BufferedImage image = ImageIO.read(new URL(imageUrl));
                return new ImageIcon(image);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
