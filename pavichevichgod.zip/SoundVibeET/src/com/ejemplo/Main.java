package com.ejemplo;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Abre la vista principal al iniciar
            new MainView().setVisible(true);
        });
    }
}
