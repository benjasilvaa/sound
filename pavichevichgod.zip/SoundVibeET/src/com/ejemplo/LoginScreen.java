package com.ejemplo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class LoginScreen extends JFrame {
	private boolean verifyUser(String username, String password) {
	    try (Connection conn = DatabaseConnection.getConnection()) {
	        if (conn != null) {
	            String sql = "SELECT * FROM usuarios WHERE nombre = ? AND contraseña = ?";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setString(1, username);
	            statement.setString(2, password);
	            ResultSet resultSet = statement.executeQuery();

	            // Si hay un resultado, el usuario y la contraseña son correctos
	            return resultSet.next();
	        }
	    } catch (SQLException e) {
	        System.out.println("Error al verificar el usuario: " + e.getMessage());
	    }
	    return false; // Devuelve false si hay algún error o si el usuario no existe
	}

    public LoginScreen() {
        setTitle("Iniciar Sesión o Registrarse");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel de fondo negro
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Color.BLACK);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Espaciado

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBackground(Color.BLACK);

        JLabel userLabel = new JLabel("Usuario:");
        JTextField userField = new JTextField();
        JLabel passLabel = new JLabel("Contraseña:");
        JPasswordField passField = new JPasswordField();
        
        // Estilo de fuentes en blanco
        userLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        userLabel.setForeground(Color.WHITE);
        passLabel.setForeground(Color.WHITE);
        userField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        passField.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JCheckBox showPassword = new JCheckBox("Mostrar Contraseña");
        showPassword.setBackground(Color.BLACK);
        showPassword.setForeground(Color.WHITE);

        // Botones fucsia
        JButton loginButton = createStyledButton("Iniciar Sesión");
        JButton registerButton = createStyledButton("Registrarse");

        // Añadir componentes al panel
        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(new JLabel()); // Espacio vacío
        panel.add(showPassword);
        panel.add(new JLabel()); // Espacio vacío
        panel.add(loginButton);
        panel.add(new JLabel()); // Espacio vacío
        panel.add(registerButton);

        mainPanel.add(panel);
        add(mainPanel);

        // Mostrar/ocultar contraseña
        showPassword.addActionListener(e -> passField.setEchoChar(showPassword.isSelected() ? (char) 0 : '•'));

        // Acción del botón de iniciar sesión
     // Acción del botón de iniciar sesión
        loginButton.addActionListener(e -> {
            if (userField.getText().isEmpty() || passField.getPassword().length == 0) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                String username = userField.getText();
                String password = new String(passField.getPassword());

                // Verifica las credenciales
                if (verifyUser(username, password)) {
                    dispose(); // Cierra la pantalla de login
                    new YouTubePlayerGUI();
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        // Acción del botón de registro
        registerButton.addActionListener(e -> new RegisterScreen().setVisible(true));
    }

    // Método para crear botones fucsia estilizados
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 20, 147)); // Fucsia
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}
